﻿INSERT INTO Prod_Category(Type_ID, Animal_Type, Produce_Type) VALUES
(1, 'Dog', 'Raw'),
(2, 'Dog', 'Kibble'),
(3, 'Dog', 'Canned'),
(4, 'Cat', 'Raw'),
(5, 'Cat', 'Kibble'),
(6, 'Cat', 'Canned');